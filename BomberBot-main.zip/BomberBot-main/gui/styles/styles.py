# /home/xty/Documents/Projects/PetProject/BomberBot_GUI/BomberBot_GUI/gui/styles/styles.py

GREEN_DOT = "background-color: #4CAF50; border-radius: 6px;"
RED_DOT = "background-color: #F44336; border-radius: 6px;"
